--%%name = "multQA"

function QuickApp:onInit()   --TBD
  self:debug(self.name,self.id)
end
