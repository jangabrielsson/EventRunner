--%%name = "multQA"

function QuickApp:onInit()
  self:debug(self.name,self.id)
end
